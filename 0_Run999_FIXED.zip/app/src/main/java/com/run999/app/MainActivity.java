package com.run999.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String HOME_URL = "https://run999.club/";
    private static final int ORANGE = Color.rgb(240, 90, 0);
    private static final int DARK = Color.rgb(0, 0, 0);
    private static final int FILE_CHOOSER_REQUEST = 999;

    private FrameLayout rootLayout;
    private WebView webView;
    private ProgressBar progressBar;
    private TextView refreshHint;
    private View offlineView;
    private View splashView;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean websiteStarted = false;
    private boolean refreshingByPull = false;
    private float pullStartY = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(DARK);
        window.setNavigationBarColor(DARK);

        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(DARK);

        buildMainWebViewLayer();
        buildOfflineLayer();
        buildSplashLayer();

        setContentView(rootLayout);
        setupWebView();
    }

    private void buildMainWebViewLayer() {
        LinearLayout mainLayer = new LinearLayout(this);
        mainLayer.setOrientation(LinearLayout.VERTICAL);
        mainLayer.setBackgroundColor(DARK);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            progressBar.setProgressTintList(ColorStateList.valueOf(ORANGE));
            progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(30, 30, 30)));
        }
        mainLayer.addView(progressBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(3)
        ));

        FrameLayout webHolder = new FrameLayout(this);
        webHolder.setBackgroundColor(DARK);

        webView = new WebView(this);
        webView.setBackgroundColor(DARK);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        webHolder.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        refreshHint = new TextView(this);
        refreshHint.setText("Release to refresh");
        refreshHint.setTextColor(Color.WHITE);
        refreshHint.setTextSize(14);
        refreshHint.setGravity(Gravity.CENTER);
        refreshHint.setTypeface(Typeface.DEFAULT_BOLD);
        refreshHint.setPadding(dp(14), dp(7), dp(14), dp(7));
        refreshHint.setBackground(makeRoundedDrawable(ORANGE, dp(18), Color.TRANSPARENT, 0));
        refreshHint.setVisibility(View.GONE);

        FrameLayout.LayoutParams hintParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL
        );
        hintParams.setMargins(0, dp(14), 0, 0);
        webHolder.addView(refreshHint, hintParams);

        mainLayer.addView(webHolder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        rootLayout.addView(mainLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    private void buildSplashLayer() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(dp(24), dp(28), dp(24), dp(28));
        splash.setBackground(makeVerticalGradient());
        splash.setClickable(true);

        addLogo(splash, 190, dp(18));

        TextView title = new TextView(this);
        title.setText("Welcome to RUN999");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setLetterSpacing(0.02f);
        splash.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        TextView subtitle = new TextView(this);
        subtitle.setText("Fast • Smooth • Secure Experience");
        subtitle.setTextColor(Color.rgb(220, 220, 220));
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        subtitleParams.setMargins(0, dp(8), 0, dp(26));
        splash.addView(subtitle, subtitleParams);

        Button enterButton = new Button(this);
        enterButton.setAllCaps(false);
        enterButton.setText("Enter Website");
        enterButton.setTextSize(17);
        enterButton.setTypeface(Typeface.DEFAULT_BOLD);
        enterButton.setTextColor(Color.WHITE);
        enterButton.setBackground(makeRoundedDrawable(ORANGE, dp(15), Color.TRANSPARENT, 0));
        enterButton.setPadding(dp(22), dp(12), dp(22), dp(12));
        LinearLayout.LayoutParams enterParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(56)
        );
        enterParams.setMargins(dp(18), 0, dp(18), 0);
        splash.addView(enterButton, enterParams);

        TextView smallText = new TextView(this);
        smallText.setText("Pull down to refresh • Reload button on internet off");
        smallText.setTextColor(Color.rgb(155, 155, 155));
        smallText.setTextSize(12);
        smallText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams smallParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        smallParams.setMargins(0, dp(22), 0, 0);
        splash.addView(smallText, smallParams);

        enterButton.setOnClickListener(v -> {
            startWebsite();
            splash.animate()
                    .alpha(0f)
                    .setDuration(350)
                    .withEndAction(() -> rootLayout.removeView(splash))
                    .start();
        });

        splashView = splash;
        rootLayout.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    private void buildOfflineLayer() {
        LinearLayout offline = new LinearLayout(this);
        offline.setOrientation(LinearLayout.VERTICAL);
        offline.setGravity(Gravity.CENTER);
        offline.setPadding(dp(24), dp(24), dp(24), dp(24));
        offline.setBackgroundColor(DARK);
        offline.setVisibility(View.GONE);
        offline.setClickable(true);

        addLogo(offline, 130, dp(24));

        TextView title = new TextView(this);
        title.setText("Internet Off");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        offline.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        TextView msg = new TextView(this);
        msg.setText("Connection check karo, phir Reload dabao.");
        msg.setTextColor(Color.rgb(210, 210, 210));
        msg.setTextSize(15);
        msg.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        msgParams.setMargins(0, dp(10), 0, dp(24));
        offline.addView(msg, msgParams);

        Button reloadButton = new Button(this);
        reloadButton.setAllCaps(false);
        reloadButton.setText("Reload");
        reloadButton.setTextSize(17);
        reloadButton.setTypeface(Typeface.DEFAULT_BOLD);
        reloadButton.setTextColor(Color.WHITE);
        reloadButton.setBackground(makeRoundedDrawable(ORANGE, dp(15), Color.TRANSPARENT, 0));
        LinearLayout.LayoutParams reloadParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(54)
        );
        reloadParams.setMargins(dp(20), 0, dp(20), 0);
        offline.addView(reloadButton, reloadParams);

        reloadButton.setOnClickListener(v -> {
            if (isOnline()) {
                hideOffline();
                if (!websiteStarted) {
                    startWebsite();
                } else {
                    webView.reload();
                }
            } else {
                Toast.makeText(this, "Internet abhi bhi off hai", Toast.LENGTH_SHORT).show();
            }
        });

        offlineView = offline;
        rootLayout.addView(offline, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setTextZoom(100);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setOnTouchListener((v, event) -> {
            if (!websiteStarted || offlineView.getVisibility() == View.VISIBLE) return false;

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    pullStartY = event.getY();
                    refreshingByPull = false;
                    refreshHint.setVisibility(View.GONE);
                    break;
                case MotionEvent.ACTION_MOVE:
                    float distance = event.getY() - pullStartY;
                    if (webView.getScrollY() == 0 && distance > dp(95)) {
                        refreshHint.setVisibility(View.VISIBLE);
                        refreshingByPull = true;
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (refreshingByPull) {
                        refreshHint.setVisibility(View.GONE);
                        if (isOnline()) {
                            hideOffline();
                            progressBar.setVisibility(View.VISIBLE);
                            progressBar.setProgress(15);
                            webView.reload();
                        } else {
                            showOffline();
                        }
                    }
                    refreshingByPull = false;
                    break;
            }
            return false;
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (!isOnline()) {
                    showOffline();
                } else {
                    hideOffline();
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                refreshHint.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request != null && request.isForMainFrame()) {
                    showOffline();
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                showOffline();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress >= 100) {
                    progressBar.setVisibility(View.GONE);
                    refreshHint.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallbackParam, FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCallbackParam;
                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "File picker nahi mila", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(createDownloadListener());
    }

    private void startWebsite() {
        websiteStarted = true;
        if (isOnline()) {
            hideOffline();
            if (webView.getUrl() == null || webView.getUrl().trim().isEmpty()) {
                webView.loadUrl(HOME_URL);
            } else {
                webView.reload();
            }
        } else {
            showOffline();
        }
    }

    private boolean handleUrl(String url) {
        if (url == null) return false;

        if (url.startsWith("http://") || url.startsWith("https://")) {
            return false;
        }

        if (url.startsWith("intent://")) {
            try {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                String fallbackUrl = intent.getStringExtra("browser_fallback_url");
                try {
                    startActivity(intent);
                } catch (Exception appError) {
                    if (fallbackUrl != null && !fallbackUrl.trim().isEmpty()) {
                        webView.loadUrl(fallbackUrl);
                    } else {
                        Toast.makeText(this, "App open nahi ho pa raha", Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (Exception e) {
                Toast.makeText(this, "Link open nahi ho pa raha", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        try {
            Intent externalIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(externalIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Link open nahi ho pa raha", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private DownloadListener createDownloadListener() {
        return (url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) request.addRequestHeader("cookie", cookies);
                request.addRequestHeader("User-Agent", userAgent);
                request.setMimeType(mimeType);
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                request.setDescription("Downloading file...");
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, contentDisposition, mimeType)
                );
                DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                if (downloadManager != null) {
                    downloadManager.enqueue(request);
                    Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                    Toast.makeText(this, "Download start nahi hua", Toast.LENGTH_SHORT).show();
                }
            }
        };
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
            return capabilities != null &&
                    capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
                            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
        } else {
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        }
    }

    private void showOffline() {
        progressBar.setVisibility(View.GONE);
        refreshHint.setVisibility(View.GONE);
        if (offlineView != null) {
            offlineView.setVisibility(View.VISIBLE);
            offlineView.bringToFront();
        }
        if (splashView != null && splashView.getParent() != null) {
            splashView.bringToFront();
        }
    }

    private void hideOffline() {
        if (offlineView != null) {
            offlineView.setVisibility(View.GONE);
        }
    }

    private void addLogo(LinearLayout parent, int heightDp, int bottomMargin) {
        ImageView logo = new ImageView(this);
        int logoId = getResources().getIdentifier("run999_logo", "drawable", getPackageName());
        if (logoId != 0) {
            logo.setImageResource(logoId);
        }
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(heightDp)
        );
        logoParams.setMargins(0, 0, 0, bottomMargin);
        parent.addView(logo, logoParams);
    }

    private GradientDrawable makeVerticalGradient() {
        return new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(0, 0, 0), Color.rgb(16, 16, 16), Color.rgb(0, 0, 0)}
        );
    }

    private GradientDrawable makeRoundedDrawable(int fillColor, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(radius);
        if (strokeWidth > 0) {
            drawable.setStroke(strokeWidth, strokeColor);
        }
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (splashView != null && splashView.getParent() != null) {
            finish();
            return;
        }
        if (offlineView != null && offlineView.getVisibility() == View.VISIBLE && webView.getUrl() != null) {
            hideOffline();
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;

            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }

            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
