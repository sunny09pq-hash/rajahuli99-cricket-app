Rajahuli99 White Splash + New Icon Build

Changes:
- App icon updated with new circular Rajahuli99 lion logo
- Opening splash screen is now normal white loading screen
- Welcome text and logo removed from splash
- Smooth WebView, pull refresh, no internet screen unchanged

GitHub upload:
1. ZIP extract karo
2. Extract folder ke andar wali files/folders upload karo
3. Repo root me app, .github, build.gradle, settings.gradle, gradle.properties direct dikhna chahiye
4. Actions -> Build Rajahuli99 White Splash APK -> Run workflow
5. Artifact download: Rajahuli99-WHITE-SPLASH-APK
