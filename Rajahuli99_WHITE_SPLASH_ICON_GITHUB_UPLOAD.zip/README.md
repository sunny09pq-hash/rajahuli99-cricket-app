# Rajahuli99 WebView Android App

Final build with new circular app icon and clean white splash loading screen.

## Features
- Rajahuli99 WebView: https://rajahuli99.com/home
- New circular launcher icon
- White loading splash screen, no welcome/logo on opening
- Pull to refresh
- No internet screen
- WhatsApp/Telegram/social links open externally
- Smooth WebView settings

## GitHub Actions
Upload project root files to GitHub, then run **Build Rajahuli99 White Splash APK** from the Actions tab.

Artifact name: `Rajahuli99-WHITE-SPLASH-APK`
APK name: `Rajahuli99-White-Splash.apk`
