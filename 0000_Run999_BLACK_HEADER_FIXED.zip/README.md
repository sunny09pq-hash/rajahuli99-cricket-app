# Run999 Black Mode Fixed

Fixed: header position, black theme injection, direct loading splash, and full white-background app icon.
