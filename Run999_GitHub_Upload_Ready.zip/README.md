# Run999 WebView APK

Ye Android WebView app `https://run999.club/` ko APK app me open karta hai.

## Features

- App name: **Run999**
- Package: `com.run999.app`
- Website: `https://run999.club/`
- Custom logo icon included
- Black/orange splash screen
- Welcome text: **Welcome to RUN999**
- Enter Website button
- Pull to refresh
- Internet off screen with Reload button
- Back button support
- Smooth WebView settings
- File upload support for website forms
- Download support
- WhatsApp / Telegram / UPI / external app links support

## GitHub se APK kaise build kare

1. GitHub par new repository banao.
2. Is ZIP ke andar wale saare files upload karo.
3. Repository me **Actions** tab open karo.
4. **Build Run999 APK** workflow select karo.
5. **Run workflow** dabao.
6. Build complete hone ke baad bottom me **Artifacts** section me `Run999-APK` milega.
7. Artifact download karo, unzip karo, andar `Run999.apk` milega.
8. Phone me install karte waqt **Install unknown apps** allow karna padega.

## Website URL change karna ho to

`app/src/main/java/com/run999/app/MainActivity.java` me ye line edit karo:

```java
private static final String HOME_URL = "https://run999.club/";
```

## App name change karna ho to

`app/src/main/res/values/strings.xml` me edit karo:

```xml
<string name="app_name">Run999</string>
```
