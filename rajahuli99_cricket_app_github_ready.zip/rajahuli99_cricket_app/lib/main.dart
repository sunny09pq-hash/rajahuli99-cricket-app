import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

void main() {
  runApp(const Rajahuli99App());
}

class Rajahuli99App extends StatelessWidget {
  const Rajahuli99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Rajahuli99 Cricket',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.black,
        fontFamily: 'Roboto',
        colorScheme: const ColorScheme.dark(
          primary: AppColors.red,
          secondary: AppColors.gold,
          surface: AppColors.card,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

class AppColors {
  static const Color black = Color(0xFF050505);
  static const Color card = Color(0xFF111111);
  static const Color card2 = Color(0xFF1B0C0C);
  static const Color red = Color(0xFFE50914);
  static const Color deepRed = Color(0xFF7B0007);
  static const Color gold = Color(0xFFFFC84D);
  static const Color muted = Color(0xFF9B9B9B);
  static const Color border = Color(0xFF3A1919);
}

class TeamScore {
  const TeamScore({
    required this.shortName,
    required this.fullName,
    required this.score,
    required this.overs,
    required this.accent,
  });

  final String shortName;
  final String fullName;
  final String score;
  final String overs;
  final Color accent;
}

class CricketMatch {
  const CricketMatch({
    required this.id,
    required this.title,
    required this.matchType,
    required this.venue,
    required this.teamA,
    required this.teamB,
    required this.statusLine,
    required this.timeLine,
    required this.isLive,
  });

  final String id;
  final String title;
  final String matchType;
  final String venue;
  final TeamScore teamA;
  final TeamScore teamB;
  final String statusLine;
  final String timeLine;
  final bool isLive;
}

class BallEvent {
  const BallEvent(this.over, this.run, this.text, {this.isWicket = false});
  final String over;
  final String run;
  final String text;
  final bool isWicket;
}

class PlayerStat {
  const PlayerStat(this.name, this.r, this.b, this.fours, this.sixes, this.sr);
  final String name;
  final String r;
  final String b;
  final String fours;
  final String sixes;
  final String sr;
}

final TeamScore rcb = TeamScore(
  shortName: 'RCB',
  fullName: 'Royal Challengers Bengaluru',
  score: '186/4',
  overs: '17.2 Overs',
  accent: AppColors.gold,
);

final TeamScore csk = TeamScore(
  shortName: 'CSK',
  fullName: 'Chennai Super Kings',
  score: '171/6',
  overs: '17.2 Overs',
  accent: Colors.orange,
);

final List<CricketMatch> matches = [
  CricketMatch(
    id: 'ipl-35',
    title: 'IPL 2024 · Match 35',
    matchType: 'T20',
    venue: 'M. Chinnaswamy Stadium',
    teamA: rcb,
    teamB: csk,
    statusLine: 'RCB need 15 runs in 16 balls',
    timeLine: 'LIVE NOW',
    isLive: true,
  ),
  CricketMatch(
    id: 'ipl-36',
    title: 'IPL 2024 · Match 36',
    matchType: 'T20',
    venue: 'Wankhede Stadium',
    teamA: TeamScore(
      shortName: 'MI',
      fullName: 'Mumbai Indians',
      score: '-',
      overs: '',
      accent: Colors.blueAccent,
    ),
    teamB: TeamScore(
      shortName: 'KKR',
      fullName: 'Kolkata Knight Riders',
      score: '-',
      overs: '',
      accent: Colors.purpleAccent,
    ),
    statusLine: 'Starts in 01h 48m',
    timeLine: '12 MAY · 7:30 PM',
    isLive: false,
  ),
  CricketMatch(
    id: 'ipl-37',
    title: 'IPL 2024 · Match 37',
    matchType: 'T20',
    venue: 'Sawai Mansingh Stadium',
    teamA: TeamScore(
      shortName: 'RR',
      fullName: 'Rajasthan Royals',
      score: '-',
      overs: '',
      accent: Colors.pinkAccent,
    ),
    teamB: TeamScore(
      shortName: 'SRH',
      fullName: 'Sunrisers Hyderabad',
      score: '-',
      overs: '',
      accent: Colors.deepOrange,
    ),
    statusLine: '13 MAY · 7:30 PM',
    timeLine: 'UPCOMING',
    isLive: false,
  ),
];

final List<PlayerStat> batting = [
  PlayerStat('Virat Kohli *', '76', '48', '6', '2', '158.33'),
  PlayerStat('Faf du Plessis', '42', '28', '4', '2', '150.00'),
  PlayerStat('Rajat Patidar', '28', '16', '3', '1', '175.00'),
  PlayerStat('Glenn Maxwell', '20', '10', '1', '2', '200.00'),
  PlayerStat('Dinesh Karthik *', '12', '6', '1', '1', '200.00'),
];

final List<PlayerStat> bowling = [
  PlayerStat('T. Deshpande', '3.2', '0', '28', '1', '8.40'),
  PlayerStat('M. Pathirana', '3.0', '0', '34', '1', '11.33'),
  PlayerStat('R. Jadeja', '4.0', '0', '29', '0', '7.25'),
  PlayerStat('M. Ali', '3.0', '0', '30', '1', '10.00'),
  PlayerStat('N. Ahmad', '2.0', '0', '22', '1', '11.00'),
];

final List<BallEvent> commentary = [
  BallEvent('17.2', '4', 'FOUR! Full and outside off, Kohli drives it through extra cover.'),
  BallEvent('17.1', '1', 'Good length on off stump, Kohli pushes it to point.'),
  BallEvent('17.0', 'Wd', 'WIDE! Slower one down the leg side.'),
  BallEvent('16.6', '2', 'Short and pulled towards deep square leg. Two runs.'),
  BallEvent('16.5', '1', 'Full toss, flicked to deep mid-wicket. Single.'),
  BallEvent('16.4', '6', 'SIX! Kohli clears long-off with a clean strike.'),
  BallEvent('16.3', '1', 'Back of a length, punched to cover.'),
  BallEvent('16.2', '4', 'FOUR! Finds the gap between cover and point.'),
];

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1300), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, animation, __) => FadeTransition(
            opacity: animation,
            child: const HomeShell(),
          ),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return const BrandedBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Hero(
                tag: 'brand-logo',
                child: Image(
                  image: AssetImage('assets/images/rajahuli99_crest.png'),
                  height: 152,
                ),
              ),
              SizedBox(height: 18),
              Image(
                image: AssetImage('assets/images/rajahuli99_logo.png'),
                height: 82,
              ),
              SizedBox(height: 18),
              Text(
                'LIVE CRICKET · REAL PASSION',
                style: TextStyle(
                  letterSpacing: 1.4,
                  fontWeight: FontWeight.w700,
                  color: AppColors.gold,
                ),
              ),
              SizedBox(height: 32),
              SizedBox(
                width: 36,
                height: 36,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  color: AppColors.red,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  final pages = const [
    HomePage(),
    MatchesPage(),
    LiveCenterPage(),
    SeriesPage(),
    MorePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return BrandedBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBody: true,
        body: SafeArea(
          bottom: false,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: pages[index],
          ),
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
            child: R99BottomNav(
              selected: index,
              onSelected: (value) => setState(() => index = value),
            ),
          ),
        ),
      ),
    );
  }
}

class BrandedBackground extends StatelessWidget {
  const BrandedBackground({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.topCenter,
          radius: 1.2,
          colors: [Color(0xFF360003), AppColors.black, Color(0xFF090000)],
          stops: [0, .45, 1],
        ),
      ),
      child: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: SparksPainter())),
          Positioned.fill(child: child),
        ],
      ),
    );
  }
}

class SparksPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = AppColors.red.withOpacity(.16);
    for (int i = 0; i < 38; i++) {
      final x = (math.sin(i * 11.2) + 1) * size.width / 2;
      final y = (math.cos(i * 7.8) + 1) * size.height / 2;
      canvas.drawCircle(Offset(x, y), i.isEven ? 1.5 : 2.6, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      key: const ValueKey('home'),
      physics: const BouncingScrollPhysics(),
      slivers: [
        const SliverToBoxAdapter(child: R99Header()),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              const HeroPoster(),
              SectionTitle(
                title: 'LIVE NOW',
                action: 'View All',
                onTap: () => Navigator.push(
                  context,
                  smoothRoute(MatchDetailScreen(match: matches.first)),
                ),
              ),
              LiveMatchCard(match: matches.first),
              const SizedBox(height: 14),
              const QuickActions(),
              SectionTitle(title: 'UPCOMING MATCHES', action: 'View All', onTap: () {}),
              ...matches.skip(1).map((match) => UpcomingMatchTile(match: match)),
              SectionTitle(title: 'FEATURES', action: 'Premium', onTap: () {}),
              const FeatureGrid(),
            ]),
          ),
        ),
      ],
    );
  }
}

class R99Header extends StatelessWidget {
  const R99Header({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.menu_rounded),
            color: Colors.white,
          ),
          const Expanded(
            child: Hero(
              tag: 'brand-logo',
              child: Image(
                image: AssetImage('assets/images/rajahuli99_logo.png'),
                height: 54,
                fit: BoxFit.contain,
              ),
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: const Badge(
              backgroundColor: AppColors.red,
              child: Icon(Icons.notifications_none_rounded),
            ),
            color: Colors.white,
          ),
        ],
      ),
    );
  }
}

class HeroPoster extends StatelessWidget {
  const HeroPoster({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 210,
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.gold.withOpacity(.65)),
        boxShadow: [
          BoxShadow(
            color: AppColors.red.withOpacity(.22),
            blurRadius: 24,
            offset: const Offset(0, 14),
          ),
        ],
        gradient: const LinearGradient(
          colors: [Color(0xFF210003), Color(0xFF070707)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned(
            top: -26,
            right: -30,
            child: Opacity(
              opacity: .18,
              child: Image.asset(
                'assets/images/rajahuli99_crest.png',
                width: 220,
              ),
            ),
          ),
          Positioned(
            left: 18,
            top: 16,
            bottom: 16,
            child: Image.asset(
              'assets/images/rajahuli99_crest.png',
              width: 125,
            ),
          ),
          Positioned(
            left: 154,
            right: 16,
            top: 30,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'RAJAHULI99',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .5,
                    color: AppColors.gold,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Live cricket. Real passion. Every ball, every moment.',
                  style: TextStyle(
                    color: Colors.white,
                    height: 1.35,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Pill(text: 'FAST SCORE', color: AppColors.red),
                    const SizedBox(width: 8),
                    Pill(text: 'BALL BY BALL', color: AppColors.gold, darkText: true),
                  ],
                ),
              ],
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              height: 54,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.black.withOpacity(.0), Colors.black.withOpacity(.75)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({
    super.key,
    required this.title,
    required this.action,
    required this.onTap,
  });

  final String title;
  final String action;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: .4),
            ),
          ),
          TextButton(
            onPressed: onTap,
            style: TextButton.styleFrom(foregroundColor: AppColors.red),
            child: Text(action),
          ),
        ],
      ),
    );
  }
}

class LiveMatchCard extends StatelessWidget {
  const LiveMatchCard({super.key, required this.match});
  final CricketMatch match;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(context, smoothRoute(MatchDetailScreen(match: match))),
      child: PremiumCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const LiveBadge(),
                const Spacer(),
                Text(
                  match.title,
                  style: const TextStyle(color: AppColors.muted, fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(child: TeamBlock(team: match.teamA, showScore: true)),
                Container(
                  width: 42,
                  height: 42,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.border),
                    color: Colors.black,
                  ),
                  child: const Text('VS', style: TextStyle(fontSize: 12, color: AppColors.muted)),
                ),
                Expanded(child: TeamBlock(team: match.teamB, showScore: true)),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.deepRed.withOpacity(.62),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.red.withOpacity(.45)),
              ),
              child: Text(
                match.statusLine,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                5,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: i == 0 ? 18 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: i == 0 ? AppColors.red : Colors.white24,
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TeamBlock extends StatelessWidget {
  const TeamBlock({super.key, required this.team, required this.showScore});
  final TeamScore team;
  final bool showScore;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TeamLogo(team: team),
        const SizedBox(height: 8),
        Text(team.shortName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        const SizedBox(height: 3),
        if (showScore) ...[
          Text(team.score, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 24)),
          Text(team.overs, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
        ] else
          Text(team.fullName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
      ],
    );
  }
}

class TeamLogo extends StatelessWidget {
  const TeamLogo({super.key, required this.team, this.size = 54});
  final TeamScore team;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [team.accent, Colors.black], begin: Alignment.topLeft, end: Alignment.bottomRight),
        border: Border.all(color: AppColors.gold.withOpacity(.4)),
        boxShadow: [BoxShadow(color: team.accent.withOpacity(.35), blurRadius: 18)],
      ),
      child: Text(
        team.shortName.substring(0, math.min(2, team.shortName.length)),
        style: TextStyle(fontWeight: FontWeight.w900, color: team.accent.computeLuminance() > .45 ? Colors.black : Colors.white),
      ),
    );
  }
}

class LiveBadge extends StatelessWidget {
  const LiveBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        gradient: const LinearGradient(colors: [AppColors.red, AppColors.deepRed]),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.circle, size: 7, color: Colors.white),
          SizedBox(width: 6),
          Text('LIVE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class UpcomingMatchTile extends StatelessWidget {
  const UpcomingMatchTile({super.key, required this.match});
  final CricketMatch match;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: PremiumCard(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            TeamLogo(team: match.teamA, size: 44),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${match.teamA.shortName} vs ${match.teamB.shortName}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  const SizedBox(height: 4),
                  Text(match.title, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(match.venue, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                TeamLogo(team: match.teamB, size: 44),
                const SizedBox(height: 8),
                Text(match.statusLine, style: const TextStyle(color: AppColors.red, fontWeight: FontWeight.w800, fontSize: 12)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class QuickActions extends StatelessWidget {
  const QuickActions({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: QuickAction(icon: Icons.sports_cricket, title: 'Live Scores', subtitle: 'Ball by ball')),
        const SizedBox(width: 10),
        Expanded(child: QuickAction(icon: Icons.notifications_active_outlined, title: 'Alerts', subtitle: 'Fast updates')),
        const SizedBox(width: 10),
        Expanded(child: QuickAction(icon: Icons.bar_chart_rounded, title: 'Stats', subtitle: 'Deep insights')),
      ],
    );
  }
}

class QuickAction extends StatelessWidget {
  const QuickAction({super.key, required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
      child: Column(
        children: [
          Icon(icon, color: AppColors.gold, size: 28),
          const SizedBox(height: 8),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
          const SizedBox(height: 2),
          Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, fontSize: 10)),
        ],
      ),
    );
  }
}

class FeatureGrid extends StatelessWidget {
  const FeatureGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.speed_rounded, 'Fast & Accurate', 'Real-time style updates'),
      (Icons.scoreboard_rounded, 'Scorecard', 'Batting + bowling table'),
      (Icons.chat_bubble_outline_rounded, 'Commentary', 'Every ball detail'),
      (Icons.workspace_premium_rounded, 'Premium UI', 'Red black gold theme'),
    ];
    return GridView.builder(
      itemCount: items.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.42,
      ),
      itemBuilder: (context, i) {
        final item = items[i];
        return PremiumCard(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(item.$1, color: AppColors.gold),
              const Spacer(),
              Text(item.$2, style: const TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 3),
              Text(item.$3, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
            ],
          ),
        );
      },
    );
  }
}

class MatchesPage extends StatelessWidget {
  const MatchesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      key: const ValueKey('matches'),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 120),
      physics: const BouncingScrollPhysics(),
      children: [
        const PageTitle(title: 'Matches', subtitle: 'Live, upcoming and finished matches'),
        const SizedBox(height: 14),
        Row(
          children: [
            Pill(text: 'All', color: AppColors.red),
            const SizedBox(width: 8),
            Pill(text: 'Live', color: AppColors.deepRed),
            const SizedBox(width: 8),
            Pill(text: 'T20', color: Colors.white12),
            const SizedBox(width: 8),
            Pill(text: 'ODI', color: Colors.white12),
          ],
        ),
        const SizedBox(height: 18),
        LiveMatchCard(match: matches.first),
        const SizedBox(height: 12),
        ...matches.skip(1).map((match) => UpcomingMatchTile(match: match)),
      ],
    );
  }
}

class LiveCenterPage extends StatelessWidget {
  const LiveCenterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      key: const ValueKey('live'),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 120),
      physics: const BouncingScrollPhysics(),
      children: [
        const PageTitle(title: 'Live Centre', subtitle: 'Fast score, recent balls and match momentum'),
        const SizedBox(height: 14),
        MatchHeaderCard(match: matches.first),
        const SizedBox(height: 14),
        const MomentumCard(),
        const SizedBox(height: 14),
        RecentBallsRow(events: commentary.take(8).toList()),
        const SizedBox(height: 14),
        PremiumButton(
          text: 'Open Match Details',
          icon: Icons.open_in_new_rounded,
          onTap: () => Navigator.push(context, smoothRoute(MatchDetailScreen(match: matches.first))),
        ),
      ],
    );
  }
}

class SeriesPage extends StatelessWidget {
  const SeriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final teams = ['India', 'England', 'Australia', 'South Africa', 'Pakistan', 'New Zealand', 'Sri Lanka', 'Bangladesh'];
    return ListView(
      key: const ValueKey('series'),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 120),
      physics: const BouncingScrollPhysics(),
      children: [
        const PageTitle(title: 'Series & Teams', subtitle: 'Explore teams, series and standings'),
        const SizedBox(height: 14),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: teams.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.25,
          ),
          itemBuilder: (context, i) => PremiumCard(
            padding: const EdgeInsets.all(14),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/images/rajahuli99_crest.png', height: 54),
                const SizedBox(height: 10),
                Text(teams[i], style: const TextStyle(fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      key: const ValueKey('more'),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 120),
      physics: const BouncingScrollPhysics(),
      children: [
        const PageTitle(title: 'More', subtitle: 'Rajahuli99 app settings'),
        const SizedBox(height: 16),
        PremiumCard(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Image.asset('assets/images/rajahuli99_logo.png', height: 72),
              const SizedBox(height: 10),
              const Text(
                'Premium red and black cricket score app UI with live score, scorecard and commentary screens.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        MoreTile(icon: Icons.person_outline_rounded, title: 'Player Profile', onTap: () => Navigator.push(context, smoothRoute(const PlayerProfileScreen()))),
        MoreTile(icon: Icons.notifications_none_rounded, title: 'Notifications', onTap: () {}),
        MoreTile(icon: Icons.privacy_tip_outlined, title: 'Privacy Policy', onTap: () {}),
        MoreTile(icon: Icons.support_agent_rounded, title: 'Support', onTap: () {}),
      ],
    );
  }
}

class MatchDetailScreen extends StatelessWidget {
  const MatchDetailScreen({super.key, required this.match});
  final CricketMatch match;

  @override
  Widget build(BuildContext context) {
    return BrandedBackground(
      child: DefaultTabController(
        length: 4,
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: true,
            title: const Text('Match Details', style: TextStyle(fontWeight: FontWeight.w900)),
            actions: const [
              Padding(
                padding: EdgeInsets.only(right: 14),
                child: Row(
                  children: [Icon(Icons.circle, color: AppColors.red, size: 10), SizedBox(width: 6), Text('LIVE', style: TextStyle(color: AppColors.red, fontWeight: FontWeight.w900))],
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: MatchHeaderCard(match: match),
              ),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(.55),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: const TabBar(
                  indicatorColor: AppColors.red,
                  labelColor: AppColors.red,
                  unselectedLabelColor: Colors.white70,
                  dividerColor: Colors.transparent,
                  tabs: [
                    Tab(text: 'Live'),
                    Tab(text: 'Scorecard'),
                    Tab(text: 'Commentary'),
                    Tab(text: 'Stats'),
                  ],
                ),
              ),
              const Expanded(
                child: TabBarView(
                  children: [
                    LiveTab(),
                    ScorecardTab(),
                    CommentaryTab(),
                    StatsTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MatchHeaderCard extends StatelessWidget {
  const MatchHeaderCard({super.key, required this.match});
  final CricketMatch match;

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Text(match.title, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
          const SizedBox(height: 15),
          Row(
            children: [
              Expanded(child: TeamBlock(team: match.teamA, showScore: true)),
              const SizedBox(width: 8),
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: Colors.black, shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
                child: const Text('VS', style: TextStyle(color: AppColors.muted)),
              ),
              const SizedBox(width: 8),
              Expanded(child: TeamBlock(team: match.teamB, showScore: true)),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.deepRed.withOpacity(.72),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(match.statusLine, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
      physics: const BouncingScrollPhysics(),
      children: const [
        MomentumCard(),
        SizedBox(height: 14),
        PartnershipCard(),
        SizedBox(height: 14),
        RecentOversCard(),
        SizedBox(height: 14),
        ActionBar(),
      ],
    );
  }
}

class MomentumCard extends StatelessWidget {
  const MomentumCard({super.key});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Live Momentum', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: StatMiniCard(title: 'CRR', value: '10.73')),
              const SizedBox(width: 10),
              Expanded(child: StatMiniCard(title: 'RRR', value: '5.62')),
              const SizedBox(width: 10),
              Expanded(child: StatMiniCard(title: 'Target', value: '201')),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              minHeight: 10,
              value: .78,
              backgroundColor: Colors.white10,
              valueColor: AlwaysStoppedAnimation<Color>(AppColors.red),
            ),
          ),
          const SizedBox(height: 8),
          const Text('RCB control: 78%', style: TextStyle(color: AppColors.muted, fontSize: 12)),
        ],
      ),
    );
  }
}

class PartnershipCard extends StatelessWidget {
  const PartnershipCard({super.key});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(16),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Partnership', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.handshake_outlined, color: AppColors.gold),
              SizedBox(width: 10),
              Expanded(child: Text('Virat Kohli & Dinesh Karthik')),
              Text('38 (22)', style: TextStyle(fontWeight: FontWeight.w900)),
            ],
          ),
        ],
      ),
    );
  }
}

class RecentOversCard extends StatelessWidget {
  const RecentOversCard({super.key});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Recent Balls', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 12),
          RecentBallsRow(events: commentary.take(8).toList()),
        ],
      ),
    );
  }
}

class RecentBallsRow extends StatelessWidget {
  const RecentBallsRow({super.key, required this.events});
  final List<BallEvent> events;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: events.map((event) {
          final isBoundary = event.run == '4' || event.run == '6';
          final color = event.isWicket ? AppColors.red : isBoundary ? AppColors.gold : Colors.white24;
          return Container(
            width: 38,
            height: 38,
            margin: const EdgeInsets.only(right: 8),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white24),
              boxShadow: isBoundary ? [BoxShadow(color: color.withOpacity(.28), blurRadius: 12)] : null,
            ),
            child: Text(
              event.run,
              style: TextStyle(fontWeight: FontWeight.w900, color: color.computeLuminance() > .45 ? Colors.black : Colors.white),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class ScorecardTab extends StatelessWidget {
  const ScorecardTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
      physics: const BouncingScrollPhysics(),
      children: [
        ScoreTable(title: 'Royal Challengers Bengaluru', subtitle: '186/4 (17.2 Overs)', rows: batting, isBatting: true),
        const SizedBox(height: 14),
        ScoreTable(title: 'Bowling', subtitle: 'Chennai Super Kings', rows: bowling, isBatting: false),
        const SizedBox(height: 14),
        PremiumCard(
          padding: const EdgeInsets.all(16),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Yet To Bat', style: TextStyle(fontWeight: FontWeight.w900)),
              SizedBox(height: 8),
              Text('Mahipal Lomror, Karn Sharma, Mohammed Siraj, Yash Dayal, Alzarri Joseph, Reece Topley', style: TextStyle(color: AppColors.muted, height: 1.4)),
            ],
          ),
        ),
      ],
    );
  }
}

class ScoreTable extends StatelessWidget {
  const ScoreTable({super.key, required this.title, required this.subtitle, required this.rows, required this.isBatting});
  final String title;
  final String subtitle;
  final List<PlayerStat> rows;
  final bool isBatting;

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [AppColors.deepRed, Color(0xFF210000)]),
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Row(
              children: [
                Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900))),
                Text(subtitle, style: const TextStyle(fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(
              children: [
                TableHeader(labels: isBatting ? const ['Batsmen', 'R', 'B', '4s', '6s', 'SR'] : const ['Bowlers', 'O', 'M', 'R', 'W', 'Econ']),
                const Divider(color: AppColors.border),
                ...rows.map((row) => PlayerRow(row: row)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TableHeader extends StatelessWidget {
  const TableHeader({super.key, required this.labels});
  final List<String> labels;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(flex: 4, child: Text(labels[0], style: const TextStyle(color: AppColors.muted, fontSize: 12, fontWeight: FontWeight.w800))),
        ...labels.skip(1).map((label) => Expanded(child: Text(label, textAlign: TextAlign.right, style: const TextStyle(color: AppColors.muted, fontSize: 12, fontWeight: FontWeight.w800)))),
      ],
    );
  }
}

class PlayerRow extends StatelessWidget {
  const PlayerRow({super.key, required this.row});
  final PlayerStat row;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(flex: 4, child: Text(row.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13))),
          Expanded(child: Text(row.r, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13))),
          Expanded(child: Text(row.b, textAlign: TextAlign.right, style: const TextStyle(fontSize: 13))),
          Expanded(child: Text(row.fours, textAlign: TextAlign.right, style: const TextStyle(fontSize: 13))),
          Expanded(child: Text(row.sixes, textAlign: TextAlign.right, style: const TextStyle(fontSize: 13))),
          Expanded(child: Text(row.sr, textAlign: TextAlign.right, style: const TextStyle(fontSize: 13))),
        ],
      ),
    );
  }
}

class CommentaryTab extends StatelessWidget {
  const CommentaryTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
      physics: const BouncingScrollPhysics(),
      children: [
        PremiumCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Text('Ball by Ball', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  Spacer(),
                  Icon(Icons.filter_alt_outlined, color: AppColors.gold),
                ],
              ),
              const SizedBox(height: 12),
              ...commentary.map((event) => CommentaryTile(event: event)),
            ],
          ),
        ),
      ],
    );
  }
}

class CommentaryTile extends StatelessWidget {
  const CommentaryTile({super.key, required this.event});
  final BallEvent event;

  @override
  Widget build(BuildContext context) {
    final isHot = event.run == '4' || event.run == '6';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isHot ? AppColors.deepRed.withOpacity(.45) : Colors.white.withOpacity(.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: isHot ? AppColors.red.withOpacity(.45) : AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 40, child: Text(event.over, style: const TextStyle(color: AppColors.muted, fontSize: 12))),
          Container(
            width: 32,
            height: 32,
            alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: isHot ? AppColors.red : Colors.white24),
            child: Text(event.run, style: const TextStyle(fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(event.text, style: const TextStyle(height: 1.35))),
        ],
      ),
    );
  }
}

class StatsTab extends StatelessWidget {
  const StatsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
      physics: const BouncingScrollPhysics(),
      children: [
        const MomentumCard(),
        const SizedBox(height: 14),
        PremiumCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Match Stats', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              const SizedBox(height: 14),
              StatLine(label: 'Boundaries', left: '16', right: '13'),
              StatLine(label: 'Wickets', left: '4', right: '6'),
              StatLine(label: 'Run Rate', left: '10.73', right: '9.86'),
              StatLine(label: 'Dots', left: '31', right: '38'),
            ],
          ),
        ),
      ],
    );
  }
}

class StatLine extends StatelessWidget {
  const StatLine({super.key, required this.label, required this.left, required this.right});
  final String label;
  final String left;
  final String right;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(
        children: [
          SizedBox(width: 42, child: Text(left, style: const TextStyle(fontWeight: FontWeight.w900))),
          Expanded(child: Text(label, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted))),
          SizedBox(width: 42, child: Text(right, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900))),
        ],
      ),
    );
  }
}

class PlayerProfileScreen extends StatelessWidget {
  const PlayerProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BrandedBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, title: const Text('Player Profile')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
          physics: const BouncingScrollPhysics(),
          children: [
            PremiumCard(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Image.asset('assets/images/rajahuli99_crest.png', height: 120),
                  const SizedBox(height: 10),
                  const Text('Virat Kohli', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  const Text('RCB · Batsman · #18', style: TextStyle(color: AppColors.muted)),
                  const SizedBox(height: 18),
                  Row(
                    children: const [
                      Expanded(child: StatMiniCard(title: 'Matches', value: '252')),
                      SizedBox(width: 10),
                      Expanded(child: StatMiniCard(title: 'Runs', value: '8124')),
                      SizedBox(width: 10),
                      Expanded(child: StatMiniCard(title: 'SR', value: '132.48')),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            PremiumCard(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Recent Performances', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  SizedBox(height: 12),
                  StatLine(label: 'vs CSK', left: '72*', right: '48 balls'),
                  StatLine(label: 'vs RR', left: '1', right: '4 balls'),
                  StatLine(label: 'vs KKR', left: '113', right: '72 balls'),
                  StatLine(label: 'vs GT', left: '55*', right: '35 balls'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ActionBar extends StatelessWidget {
  const ActionBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: PremiumButton(text: 'Match Centre', icon: Icons.sports_score_rounded, onTap: () {})),
        const SizedBox(width: 10),
        Expanded(child: PremiumButton(text: 'Watch Live', icon: Icons.play_circle_outline_rounded, onTap: () {})),
      ],
    );
  }
}

class PremiumButton extends StatelessWidget {
  const PremiumButton({super.key, required this.text, required this.icon, required this.onTap});
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: const LinearGradient(colors: [AppColors.red, AppColors.deepRed]),
            boxShadow: [BoxShadow(color: AppColors.red.withOpacity(.25), blurRadius: 16)],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18),
              const SizedBox(width: 8),
              Text(text, style: const TextStyle(fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      ),
    );
  }
}

class MoreTile extends StatelessWidget {
  const MoreTile({super.key, required this.icon, required this.title, required this.onTap});
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: PremiumCard(
        padding: EdgeInsets.zero,
        child: ListTile(
          onTap: onTap,
          leading: Icon(icon, color: AppColors.gold),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          trailing: const Icon(Icons.chevron_right_rounded),
        ),
      ),
    );
  }
}

class PageTitle extends StatelessWidget {
  const PageTitle({super.key, required this.title, required this.subtitle});
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.asset('assets/images/rajahuli99_logo.png', height: 60),
        const SizedBox(height: 8),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 30)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: AppColors.muted)),
      ],
    );
  }
}

class StatMiniCard extends StatelessWidget {
  const StatMiniCard({super.key, required this.title, required this.value});
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.45),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Text(title, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        ],
      ),
    );
  }
}

class PremiumCard extends StatelessWidget {
  const PremiumCard({super.key, required this.child, required this.padding});
  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(
          colors: [Colors.white.withOpacity(.06), AppColors.card2.withOpacity(.65), AppColors.card.withOpacity(.92)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: AppColors.gold.withOpacity(.28)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(.35), blurRadius: 18, offset: const Offset(0, 10)),
        ],
      ),
      child: child,
    );
  }
}

class Pill extends StatelessWidget {
  const Pill({super.key, required this.text, required this.color, this.darkText = false});
  final String text;
  final Color color;
  final bool darkText;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white24),
      ),
      child: Text(
        text,
        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 11, color: darkText ? Colors.black : Colors.white),
      ),
    );
  }
}

class R99BottomNav extends StatelessWidget {
  const R99BottomNav({super.key, required this.selected, required this.onSelected});
  final int selected;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.home_rounded, 'Home'),
      (Icons.emoji_events_outlined, 'Matches'),
      (Icons.sensors_rounded, 'Live'),
      (Icons.scoreboard_outlined, 'Series'),
      (Icons.more_horiz_rounded, 'More'),
    ];
    return Container(
      height: 72,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.92),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.gold.withOpacity(.32)),
        boxShadow: [BoxShadow(color: AppColors.red.withOpacity(.22), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Row(
        children: List.generate(items.length, (i) {
          final isSelected = selected == i;
          return Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: () => onSelected(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.deepRed.withOpacity(.58) : Colors.transparent,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(items[i].$1, color: isSelected ? AppColors.red : Colors.white60),
                    const SizedBox(height: 4),
                    Text(
                      items[i].$2,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                        color: isSelected ? AppColors.red : Colors.white60,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

Route<T> smoothRoute<T>(Widget page) {
  return PageRouteBuilder<T>(
    transitionDuration: const Duration(milliseconds: 260),
    reverseTransitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, __, child) {
      final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(.04, .02), end: Offset.zero).animate(curved),
          child: child,
        ),
      );
    },
  );
}
