const express = require('express');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

const liveMatch = {
  id: 'ipl-35',
  title: 'IPL 2024 · Match 35',
  venue: 'M. Chinnaswamy Stadium',
  isLive: true,
  teamA: {
    shortName: 'RCB',
    fullName: 'Royal Challengers Bengaluru',
    score: '186/4',
    overs: '17.2 Overs',
  },
  teamB: {
    shortName: 'CSK',
    fullName: 'Chennai Super Kings',
    score: '171/6',
    overs: '17.2 Overs',
  },
  statusLine: 'RCB need 15 runs in 16 balls',
  recentBalls: ['4', '1', 'Wd', '2', '1', '6', '1', '4'],
};

const upcoming = [
  {
    id: 'ipl-36',
    title: 'IPL 2024 · Match 36',
    venue: 'Wankhede Stadium',
    teamA: { shortName: 'MI', fullName: 'Mumbai Indians' },
    teamB: { shortName: 'KKR', fullName: 'Kolkata Knight Riders' },
    statusLine: '12 MAY · 7:30 PM',
  },
  {
    id: 'ipl-37',
    title: 'IPL 2024 · Match 37',
    venue: 'Sawai Mansingh Stadium',
    teamA: { shortName: 'RR', fullName: 'Rajasthan Royals' },
    teamB: { shortName: 'SRH', fullName: 'Sunrisers Hyderabad' },
    statusLine: '13 MAY · 7:30 PM',
  },
];

const scorecard = {
  batting: [
    { name: 'Virat Kohli *', r: 76, b: 48, fours: 6, sixes: 2, sr: '158.33' },
    { name: 'Faf du Plessis', r: 42, b: 28, fours: 4, sixes: 2, sr: '150.00' },
    { name: 'Rajat Patidar', r: 28, b: 16, fours: 3, sixes: 1, sr: '175.00' },
    { name: 'Glenn Maxwell', r: 20, b: 10, fours: 1, sixes: 2, sr: '200.00' },
  ],
  bowling: [
    { name: 'T. Deshpande', overs: '3.2', maidens: 0, runs: 28, wickets: 1, econ: '8.40' },
    { name: 'M. Pathirana', overs: '3.0', maidens: 0, runs: 34, wickets: 1, econ: '11.33' },
  ],
};

const commentary = [
  { over: '17.2', run: '4', text: 'FOUR! Full and outside off, Kohli drives through cover.' },
  { over: '17.1', run: '1', text: 'Good length on off stump, Kohli pushes it to point.' },
  { over: '17.0', run: 'Wd', text: 'WIDE! Slower one down the leg side.' },
  { over: '16.6', run: '2', text: 'Short and pulled towards deep square leg.' },
];

app.get('/api/health', (_, res) => res.json({ ok: true, app: 'Rajahuli99 Cricket API' }));
app.get('/api/matches/live', (_, res) => res.json([liveMatch]));
app.get('/api/matches/upcoming', (_, res) => res.json(upcoming));
app.get('/api/match/:id', (_, res) => res.json(liveMatch));
app.get('/api/match/:id/scorecard', (_, res) => res.json(scorecard));
app.get('/api/match/:id/commentary', (_, res) => res.json(commentary));

app.listen(port, () => {
  console.log(`Rajahuli99 Cricket API running on http://localhost:${port}`);
});
