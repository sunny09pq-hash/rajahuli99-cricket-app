# Rajahuli99 Cricket Score App

Premium red/black/gold Flutter UI for a cricket score app.

## Isme kya hai

- Splash screen with Rajahuli99 logo
- Home page
- Live score card
- Upcoming matches
- Match details page
- Live tab, scorecard tab, commentary tab, stats tab
- Player profile page
- Smooth navigation animations
- Mock Node.js backend API
- Red + black theme, gold premium accents

## Flutter app run karne ka tarika

1. Flutter install karo.
2. Terminal open karo.
3. Is folder ke andar run karo:

```bash
flutter create .
flutter pub get
flutter run
```

Note: `flutter create .` native Android/iOS files generate karega.

## Backend run karne ka tarika

```bash
cd backend
npm install
npm run dev
```

Backend URL: `http://localhost:4000`

## Real live score API connect kaise karna hai

Abhi app demo/mock data par chal raha hai taaki UI smooth rahe. Real live data ke liye aapko Cricket API key chahiye. Backend me API key rakhni hai, mobile app me direct key nahi dalni.

Recommended flow:

```text
Flutter App -> Your Backend -> Cricket Data Provider API
```

Backend endpoints ready hain:

```text
GET /api/matches/live
GET /api/matches/upcoming
GET /api/match/:id
GET /api/match/:id/scorecard
GET /api/match/:id/commentary
```

## Important

Koi bhi app bina device testing ke 100% bug-free guarantee nahi hota. Ye code clean starter/final UI build hai. App store ya production ke liye real API, push notifications, app icon, privacy policy aur device testing zaroori hai.


## GitHub se APK build/install

Is repo me GitHub Actions workflow added hai:

```text
.github/workflows/build-apk.yml
```

GitHub repo me upload karne ke baad Actions tab se `Build Rajahuli99 Android APK` run karo. Build complete hone ke baad artifact me `Rajahuli99-Cricket.apk` milega. Full steps ke liye `GITHUB_INSTALL_GUIDE.md` dekho.
