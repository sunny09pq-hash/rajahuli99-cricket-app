# GitHub repo se APK install karne ka tarika

## 1. GitHub par new repo banao
1. GitHub app/website open karo.
2. New repository banao.
3. Repo name rakho: `rajahuli99-cricket-app`.
4. Public ya Private kuch bhi rakh sakte ho.

## 2. Ye project upload karo
Is folder ke andar ke saare files GitHub repo me upload karo:

```text
.github/workflows/build-apk.yml
assets/
backend/
lib/
pubspec.yaml
analysis_options.yaml
README.md
```

## 3. APK build karna
1. Repo open karo.
2. Actions tab open karo.
3. `Build Rajahuli99 Android APK` workflow select karo.
4. `Run workflow` dabao.
5. Build complete hone ka wait karo.

## 4. APK download/install karna
1. Latest successful workflow open karo.
2. Artifacts section me `Rajahuli99-Cricket-APK` download karo.
3. ZIP extract karo.
4. `Rajahuli99-Cricket.apk` phone me install karo.
5. Phone me “Install unknown apps” allow karna padega.

## Notes
- GitHub source code direct install nahi hota. Install karne ke liye APK file chahiye.
- Abhi app demo/mock cricket data par hai.
- Real live score ke liye backend me paid/free cricket API key connect karni hogi.
