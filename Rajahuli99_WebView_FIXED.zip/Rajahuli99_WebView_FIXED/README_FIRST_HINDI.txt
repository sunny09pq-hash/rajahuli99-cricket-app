RAJAHULI99 WEBVIEW APP - IMPORTANT

Ye Cricket app nahi hai. Ye website WebView app hai.
Website URL: https://rajahuli99.com/home
App name: Rajahuli99
Package: com.rajahuli99.webview

GitHub me upload karne se pehle:
1. Purane repo me Cricket app wali saari files delete karo, ya bilkul NEW repo banao.
2. Is ZIP ko extract karo.
3. Extract ke andar wali files/folders GitHub repo ke root me upload karo:
   app, .github, build.gradle, settings.gradle, gradle.properties
4. GitHub > Actions > Build Rajahuli99 WEBVIEW APK open karo.
5. Run workflow dabao.
6. Build complete hone ke baad Artifacts me Rajahuli99-WEBVIEW-APK download karo.
7. ZIP extract karo, andar Rajahuli99-WebView.apk install karo.

Agar download ZIP ka naam Cricket dikhe, to galat/old workflow download ho raha hai.
Sahi artifact ka naam: Rajahuli99-WEBVIEW-APK
Sahi APK ka naam: Rajahuli99-WebView.apk
