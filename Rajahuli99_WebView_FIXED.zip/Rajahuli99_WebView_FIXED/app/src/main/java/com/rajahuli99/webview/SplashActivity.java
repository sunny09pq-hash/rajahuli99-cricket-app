package com.rajahuli99.webview;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.BLACK);
        window.setNavigationBarColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(22), dp(22), dp(22), dp(22));

        GradientDrawable background = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#050505"), Color.parseColor("#270000"), Color.parseColor("#050505")}
        );
        root.setBackground(background);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.rajahuli_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(170)
        );
        logoParams.setMargins(0, 0, 0, dp(18));
        root.addView(logo, logoParams);

        TextView welcome = new TextView(this);
        welcome.setText("Welcome to Rajahuli99");
        welcome.setTextColor(Color.parseColor("#E50914"));
        welcome.setTextSize(27);
        welcome.setTypeface(Typeface.DEFAULT_BOLD);
        welcome.setGravity(Gravity.CENTER);
        welcome.setShadowLayer(10, 0, 0, Color.parseColor("#FFD86B"));
        root.addView(welcome, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        TextView tagLine = new TextView(this);
        tagLine.setText("Fast • Smooth • Secure");
        tagLine.setTextColor(Color.parseColor("#FFD86B"));
        tagLine.setTextSize(15);
        tagLine.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tagParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        tagParams.setMargins(0, dp(8), 0, dp(30));
        root.addView(tagLine, tagParams);

        ProgressBar loader = new ProgressBar(this);
        root.addView(loader, new LinearLayout.LayoutParams(dp(52), dp(52)));

        setContentView(root);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        }, 2200);
    }
}
