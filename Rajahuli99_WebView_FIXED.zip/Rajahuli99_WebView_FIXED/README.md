# Rajahuli99 Android WebView App

Website URL: `https://rajahuli99.com/home`

## Features

- Rajahuli99 app name and launcher icon
- Red/black splash screen with Rajahuli99 logo
- WebView app for the website
- Bottom navigation buttons: Home, Back, Refresh, Forward
- Pull to refresh
- No Internet screen with Retry button
- WhatsApp, Telegram, Instagram, Facebook, YouTube, phone, email, and intent links open in the correct external app/browser
- File chooser support for upload buttons inside the website
- Download links open in external browser/app

## GitHub se APK kaise banaye

1. Is project ke sab files GitHub repository me upload karo.
2. GitHub repository me **Actions** tab open karo.
3. Left side me **Build Android APK** workflow choose karo.
4. **Run workflow** button dabao.
5. Build complete hone ke baad bottom me **Artifacts** section me `Rajahuli99-debug-apk` milega.
6. Artifact download karo, unzip karo, `app-debug.apk` install karo.

## Android Studio se build

1. Android Studio open karo.
2. **Open** select karke ye project folder choose karo.
3. Gradle sync complete hone do.
4. Menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK path: `app/build/outputs/apk/debug/app-debug.apk`.

