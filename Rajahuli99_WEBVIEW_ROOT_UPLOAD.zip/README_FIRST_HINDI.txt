IMPORTANT - IS ZIP KO SAHI TARAH UPLOAD KARO

Ye Rajahuli99 WEBVIEW app hai. Cricket app nahi.

GitHub me upload karte time outer folder upload mat karo.
Repo ke root me ye files/folders directly dikhne chahiye:

app
.github
build.gradle
settings.gradle
gradle.properties
README.md

Agar root me Rajahuli99_WEBVIEW_ROOT_UPLOAD naam ka folder dikh raha hai, to galat upload hua hai.

Purana workflow replace hona chahiye:
.github/workflows/build-apk.yml

Actions me workflow ka naam hona chahiye:
Build Rajahuli99 WEBVIEW APK

Artifact name:
Rajahuli99-WEBVIEW-APK

APK name:
Rajahuli99-WebView.apk
