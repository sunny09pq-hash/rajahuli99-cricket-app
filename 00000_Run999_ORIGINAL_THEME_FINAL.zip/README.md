Run999 APK - header fixed, direct loading splash, original website white area restored, icon fixed.
