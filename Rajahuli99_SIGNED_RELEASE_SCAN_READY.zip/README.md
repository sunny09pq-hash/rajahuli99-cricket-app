# Rajahuli99 Signed Release Safe APK

GitHub Actions se release-signed APK build hota hai.

Actions -> Build Rajahuli99 Signed Release APK -> Run workflow

Artifact: Rajahuli99-SIGNED-RELEASE-APK
