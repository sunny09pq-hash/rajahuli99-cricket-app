Rajahuli99 Smooth WebView Fixed

Fixes:
1. Bottom native buttons Home Back Refresh Forward removed.
2. Website will not go under phone status bar.
3. App icon regenerated from Rajahuli99 logo.
4. WebView settings improved for smooth loading.

Upload these project files to GitHub root, then run Actions.
Artifact name: Rajahuli99-SMOOTH-WEBVIEW-APK
APK name: Rajahuli99-Smooth-WebView.apk
